module.exports = {
  token: "",

  prefix: "Mob",
  admins: [
    "781539365989908532"
  ],
  debug: true,
  countChannel: "countChannelID"
};

