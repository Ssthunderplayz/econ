  const Discord = require("discord.js"); const client = new Discord.Client({ disableMentions: 'everyone' });const Eco = require("quick.eco");
client.eco = new Eco.Manager(); // quick.ec
client.db = Eco.db; // quick.d
client.config = require("./botConfig")
client.commands = new Discord.Collection()
client.aliases = new Discord.Collection()
client.shop = {
  "Laptop" : {
    cost: 2000
  },
  "Mobile" : {
    cost: 1000
  },
  "PC" : {
    cost: 3000
  }
};
  const fs = require("fs");

fs.readdir("./events/", (err, files) => {
    if (err) return console.error(err);
    files.forEach(f => {
        if (!f.endsWith(".js")) return;
        const event = require(`./events/${f}`);
        let eventName = f.split(".")[0];
        client.on(eventName, event.bind(null, client));
    });
});

fs.readdir("./commands/", (err, files) => {
    if (err) return console.error(err);
    files.forEach(f => {
        if (!f.endsWith(".js")) return;
        let command = require(`./commands/${f}`);
        client.commands.set(command.help.name, command);
        command.help.aliases.forEach(alias => {
            client.aliases.set(alias, command.help.name);
        });
    });
});
client.on("message", async message =>{
  if (message.content.startsWith("Mob invite"))
    {
        message.channel.send(`Here is an invite link to invite the bot https://discord.com/api/oauth2/authorize?client_id=894458852286795798&permissions=1550021689025&scope=bot`)
          }
          });
client.on("message", async message =>{
  if (message.content.startsWith("**${client.prefix}**. join"))
    {
        message.channel.send(`Here is an invite link to the support server https://discord.gg/W73GDZct4U`)
          }
          });
client.on("message", async message =>{
  if (message.content.startsWith("<@894458852286795798>"))
    {
        message.channel.send(`My prefix for this server is **${client.prefix}**.`)
          }
          });
client.on("message", async message =>{
     if (message.content.startsWith("Mob vote"))
    {
        message.channel.send(`you can vote me on this site
https://top.gg/bot/894458852286795798/vote`)
   }       
          });
    client.login("ODk0NDU4ODUyMjg2Nzk1Nzk4.YVqTuA.HshtbrDtwJfbBkW_4zv-HDjtFcA");
